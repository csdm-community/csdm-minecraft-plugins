package tv.csdm.minecraft.community.staff;

import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public final class StaffRankRegistry {
    private final Map<String, StaffRankDefinition> definitions;

    private StaffRankRegistry(Map<String, StaffRankDefinition> definitions) {
        this.definitions = Map.copyOf(definitions);
    }

    public static StaffRankRegistry load(FileConfiguration config) {
        ConfigurationSection section = config.getConfigurationSection("staff-ranks");
        if (section == null) {
            throw new IllegalArgumentException("config.yml no contiene staff-ranks");
        }
        Map<String, StaffRankDefinition> definitions = new LinkedHashMap<>();
        for (String rawId : section.getKeys(false)) {
            String id = normalize(rawId);
            ConfigurationSection rank = section.getConfigurationSection(rawId);
            if (rank == null) {
                continue;
            }
            String group = normalize(rank.getString("group", "csdm-" + id));
            definitions.put(id, new StaffRankDefinition(
                    id,
                    group,
                    rank.getString("display-name", id),
                    rank.getString("prefix", ""),
                    rank.getInt("priority", 1),
                    rank.getStringList("permissions")));
        }
        return new StaffRankRegistry(definitions);
    }

    public Optional<StaffRankDefinition> find(String id) {
        return Optional.ofNullable(definitions.get(normalize(id)));
    }

    public Optional<StaffRankDefinition> byGroup(String group) {
        String normalized = normalize(group);
        return definitions.values().stream()
                .filter(rank -> rank.group().equals(normalized))
                .max(Comparator.comparingInt(StaffRankDefinition::priority));
    }

    public Collection<StaffRankDefinition> all() {
        return definitions.values();
    }

    public Set<String> managedGroups() {
        return definitions.values().stream().map(StaffRankDefinition::group).collect(Collectors.toUnmodifiableSet());
    }

    private static String normalize(String value) {
        return value.trim().toLowerCase(Locale.ROOT).replace('_', '-');
    }
}

